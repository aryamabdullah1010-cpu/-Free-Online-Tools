import { ReactNode } from 'react';
import { FileText, Calculator, FileOutput, FileCode2, QrCode, ArrowRightLeft, Maximize, FileUp, FileDown } from 'lucide-react';

export type Category = 'Image' | 'PDF' | 'Calculator' | 'Text' | 'Generator';

export interface ToolItem {
  id: string;
  name: string;
  description: string;
  path: string;
  category: Category;
  icon: ReactNode;
  popular?: boolean;
}

export const toolsData: ToolItem[] = [
  {
    id: 'image-compressor',
    name: 'Image Compressor',
    description: 'Reduce image file size while preserving quality. Supports JPG, PNG & WebP.',
    path: '/tools/image-compressor',
    category: 'Image',
    icon: <FileDown />,
    popular: true,
  },
  {
    id: 'image-converter',
    name: 'Image Converter',
    description: 'Convert between JPG, PNG, and WebP formats instantly.',
    path: '/tools/image-converter',
    category: 'Image',
    icon: <ArrowRightLeft />,
    popular: true,
  },
  {
    id: 'image-resizer',
    name: 'Image Resizer',
    description: 'Resize images by pixels or presets for social media.',
    path: '/tools/image-resizer',
    category: 'Image',
    icon: <Maximize />,
  },
  {
    id: 'jpg-to-pdf',
    name: 'JPG to PDF',
    description: 'Convert and combine multiple images into a single PDF document.',
    path: '/tools/jpg-to-pdf',
    category: 'PDF',
    icon: <FileUp />,
    popular: true,
  },
  {
    id: 'pdf-to-jpg',
    name: 'PDF to JPG',
    description: 'Extract pages from a PDF and save them as high-quality JPGs.',
    path: '/tools/pdf-to-jpg',
    category: 'PDF',
    icon: <FileOutput />,
  },
  {
    id: 'pdf-compressor',
    name: 'PDF Compressor',
    description: 'Reduce PDF file size for easier sharing and email attachment.',
    path: '/tools/pdf-compressor',
    category: 'PDF',
    icon: <FileDown />,
    popular: true,
  },
  {
    id: 'word-counter',
    name: 'Word Counter',
    description: 'Count words, characters, sentences, and paragraphs in your text.',
    path: '/tools/word-counter',
    category: 'Text',
    icon: <FileText />,
  },
  {
    id: 'percentage-calculator',
    name: 'Percentage Calculator',
    description: 'Easily calculate percentages, increases, decreases, and more.',
    path: '/tools/percentage-calculator',
    category: 'Calculator',
    icon: <Calculator />,
  },
  {
    id: 'gpa-calculator',
    name: 'GPA Calculator',
    description: 'Calculate your college or high school GPA quickly and easily.',
    path: '/tools/gpa-calculator',
    category: 'Calculator',
    icon: <FileCode2 />,
  },
  {
    id: 'qr-code-generator',
    name: 'QR Code Generator',
    description: 'Create customizable QR codes for links, text, email, and more.',
    path: '/tools/qr-code-generator',
    category: 'Generator',
    icon: <QrCode />,
    popular: true,
  }
];
