export const blogPosts = [
  {
    slug: 'how-to-compress-an-image',
    title: 'How to Compress an Image Without Losing Quality',
    excerpt: 'Learn the best techniques to reduce image file sizes for your website or sharing, without making them look blurry.',
    date: 'Jan 15, 2026',
    author: 'QuickTools Team',
    relatedTools: ['image-compressor', 'image-resizer']
  },
  {
    slug: 'jpg-vs-png-vs-webp',
    title: 'JPG vs PNG vs WebP: Which Image Format Should You Use?',
    excerpt: 'A comprehensive guide to understanding modern image formats and knowing exactly when to use each one.',
    date: 'Jan 10, 2026',
    author: 'QuickTools Team',
    relatedTools: ['image-converter']
  },
  {
    slug: 'how-to-compress-a-pdf',
    title: 'How to Reduce PDF File Size',
    excerpt: 'Struggling to email a large PDF? Here are the best ways to shrink your documents securely.',
    date: 'Jan 5, 2026',
    author: 'QuickTools Team',
    relatedTools: ['pdf-compressor', 'pdf-to-jpg']
  }
];

export const getBlogPost = (slug: string) => blogPosts.find(post => post.slug === slug);
