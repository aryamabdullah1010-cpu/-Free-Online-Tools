interface AdSlotProps {
  className?: string;
  type?: 'horizontal' | 'rectangle';
}

export default function AdSlot({ className = '', type = 'horizontal' }: AdSlotProps) {
  // In a real app, this would check import.meta.env.VITE_ADSENSE_CLIENT
  // and render the actual <ins> tag. For now, it's a placeholder to reserve space.
  const adClientId = (import.meta as any).env.VITE_ADSENSE_CLIENT;

  if (adClientId) {
    return (
      <div className={`overflow-hidden flex justify-center items-center bg-slate-50 border border-slate-200 rounded text-slate-400 text-xs ${className}`}>
        {/* Actual AdSense code would go here */}
        Ad Placeholder ({type})
      </div>
    );
  }

  // Still render the placeholder locally if needed for layout checking, or return null
  return (
    <div className={`overflow-hidden flex justify-center items-center bg-slate-50 border border-slate-200 rounded text-slate-400 text-xs ${type === 'horizontal' ? 'h-24 w-full max-w-3xl' : 'h-64 w-full max-w-xs'} mx-auto my-6 ${className}`}>
      Advertisement Placeholder
    </div>
  );
}
