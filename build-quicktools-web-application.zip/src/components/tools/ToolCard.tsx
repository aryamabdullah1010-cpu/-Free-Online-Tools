import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { ToolItem } from '../../data/toolsData';

export default function ToolCard({ tool }: { tool: ToolItem }) {
  return (
    <div className="group flex flex-col bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 transition-all h-full relative overflow-hidden">
      <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
        {tool.icon}
      </div>
      
      <span className="inline-block px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-medium mb-3 w-max">
        {tool.category}
      </span>
      
      <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
        {tool.name}
      </h3>
      
      <p className="text-slate-600 text-sm mb-6 flex-grow">
        {tool.description}
      </p>
      
      <Link 
        to={tool.path}
        className="mt-auto inline-flex items-center text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors before:absolute before:inset-0"
      >
        Use Tool
        <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
      </Link>
    </div>
  );
}
