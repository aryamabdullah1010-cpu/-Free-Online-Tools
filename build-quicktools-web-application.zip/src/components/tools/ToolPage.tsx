import { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import SEO from '../seo/SEO';
import AdSlot from '../ads/AdSlot';

interface ToolPageProps {
  title: string;
  description: string;
  canonical?: string;
  children: ReactNode;
  faqs?: { question: string; answer: string }[];
  relatedTools?: { name: string; path: string; icon: ReactNode }[];
  howToSteps?: { title: string; description: string }[];
}

export default function ToolPage({
  title,
  description,
  canonical,
  children,
  faqs,
  relatedTools,
  howToSteps
}: ToolPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <SEO title={`${title} - QuickTools`} description={description} canonical={canonical} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumbs */}
        <nav className="flex text-sm text-slate-500 mb-6" aria-label="Breadcrumb">
          <ol className="flex items-center space-x-2">
            <li><Link to="/" className="hover:text-blue-600 transition-colors">Home</Link></li>
            <li><ChevronRight className="w-4 h-4" /></li>
            <li><Link to="/tools" className="hover:text-blue-600 transition-colors">Tools</Link></li>
            <li><ChevronRight className="w-4 h-4" /></li>
            <li className="text-slate-900 font-medium" aria-current="page">{title}</li>
          </ol>
        </nav>

        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-4">{title}</h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">{description}</p>
        </div>

        {/* Top Ad Placeholder */}
        <AdSlot className="mb-8" />

        {/* Main Tool Interface */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 md:p-8 mb-12">
          {children}
        </div>

        {/* Bottom Ad Placeholder */}
        <AdSlot className="mb-12" />

        {/* How to use */}
        {howToSteps && howToSteps.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">How to use {title}</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {howToSteps.map((step, index) => (
                <div key={index} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold mb-4">
                    {index + 1}
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">{step.title}</h3>
                  <p className="text-slate-600 text-sm">{step.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* In-content Ad Placeholder */}
        {faqs && faqs.length > 0 && <AdSlot className="mb-12" />}

        {/* FAQs */}
        {faqs && faqs.length > 0 && (
          <section className="mb-12 bg-white rounded-2xl p-8 border border-slate-200 shadow-sm">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Frequently Asked Questions</h2>
            <div className="space-y-6">
              {faqs.map((faq, index) => (
                <div key={index}>
                  <h3 className="font-semibold text-slate-900 mb-2">{faq.question}</h3>
                  <p className="text-slate-600">{faq.answer}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Related Tools */}
        {relatedTools && relatedTools.length > 0 && (
          <section className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Related Tools</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {relatedTools.map((tool, index) => (
                <Link
                  key={index}
                  to={tool.path}
                  className="flex items-center p-4 bg-white rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-md transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center text-slate-600 group-hover:text-blue-600 group-hover:bg-blue-50 transition-colors mr-4">
                    {tool.icon}
                  </div>
                  <span className="font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
                    {tool.name}
                  </span>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
