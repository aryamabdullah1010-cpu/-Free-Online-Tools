import SEO from '../components/seo/SEO';

export default function About() {
  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <SEO title="About QuickTools - Our Mission" description="Learn about QuickTools, our mission to provide fast, free, and secure online tools for everyone." />
      <div className="max-w-3xl mx-auto prose prose-slate lg:prose-lg">
        <h1 className="text-4xl font-bold text-slate-900 mb-8">About QuickTools</h1>
        <p className="text-xl text-slate-600 mb-8">
          We believe that everyday digital tasks should be simple, fast, and accessible to everyone without barriers.
        </p>
        <h2 className="text-2xl font-bold text-slate-900 mt-12 mb-4">Our Story</h2>
        <p className="text-slate-600">
          QuickTools was born out of frustration. Have you ever needed to simply resize an image, convert a PDF, or count words, only to be met with sites demanding registration, forcing you to pay, or flooding you with deceptive ads? So had we.
        </p>
        <p className="text-slate-600">
          We decided to build a platform that respects the user's time and privacy. By leveraging modern browser technologies, we process files locally on your device whenever technically possible.
        </p>
        
        <h2 className="text-2xl font-bold text-slate-900 mt-12 mb-4">Our Core Values</h2>
        <ul className="space-y-4 text-slate-600 list-disc pl-6">
          <li><strong>Speed:</strong> Instant results with minimal loading times.</li>
          <li><strong>Privacy:</strong> We don't want your files. If it can be processed in your browser, it will be.</li>
          <li><strong>Simplicity:</strong> Clean, uncluttered interfaces focused entirely on getting the job done.</li>
          <li><strong>Accessibility:</strong> Tools that work seamlessly on mobile, tablet, and desktop.</li>
        </ul>
      </div>
    </div>
  );
}
