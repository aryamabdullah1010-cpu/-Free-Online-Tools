import SEO from '../../components/seo/SEO';

export default function Terms() {
  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <SEO title="Terms of Service - QuickTools" description="Read our terms of service." />
      <div className="max-w-3xl mx-auto prose prose-slate">
        <h1>Terms of Service</h1>
        <p>Last updated: January 2026</p>
        
        <h2>1. Acceptance of Terms</h2>
        <p>By accessing and using QuickTools, you accept and agree to be bound by the terms and provision of this agreement.</p>
        
        <h2>2. Use of Service</h2>
        <p>QuickTools provides various online utilities for free. You agree to use these tools for lawful purposes only. You must not use our tools to process illegal, copyrighted, or malicious files.</p>

        <h2>3. Disclaimer of Warranties</h2>
        <p>The services are provided "as is". QuickTools makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties, including without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>

        <h2>4. Limitations of Liability</h2>
        <p>In no event shall QuickTools be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the tools on our website.</p>
        
        <h2>5. Modifications</h2>
        <p>QuickTools may revise these terms of service for its website at any time without notice. By using this website you are agreeing to be bound by the then current version of these terms of service.</p>
      </div>
    </div>
  );
}
