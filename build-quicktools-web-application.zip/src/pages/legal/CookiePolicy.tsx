import SEO from '../../components/seo/SEO';

export default function CookiePolicy() {
  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <SEO title="Cookie Policy - QuickTools" description="Read our cookie policy." />
      <div className="max-w-3xl mx-auto prose prose-slate">
        <h1>Cookie Policy</h1>
        <p>Last updated: January 2026</p>
        
        <h2>1. What are cookies?</h2>
        <p>Cookies are small text files that are placed on your computer or mobile device when you visit a website. They are widely used to make websites work more efficiently and provide information to the owners of the site.</p>
        
        <h2>2. How we use cookies</h2>
        <p>We use cookies for the following purposes:</p>
        <ul>
          <li><strong>Necessary cookies:</strong> These cookies are essential for the website to function properly. They enable basic features like page navigation and access to secure areas of the website.</li>
          <li><strong>Analytics cookies:</strong> We use these cookies to understand how visitors interact with our website. They help us measure the number of visitors and see how they navigate the site. This information is used to improve our website and services.</li>
          <li><strong>Advertising cookies:</strong> These cookies are used to deliver advertisements that are relevant to your interests. They are also used to limit the number of times you see an advertisement and measure the effectiveness of advertising campaigns. Third-party vendors, including Google, use cookies to serve ads based on your prior visits to our website or other websites.</li>
        </ul>

        <h2>3. Managing cookies</h2>
        <p>You can control and manage cookies in various ways. Most browsers allow you to block or delete cookies from websites you visit. However, please note that disabling cookies may affect the functionality of our website and some features may not work as intended.</p>
        
        <h2>4. Third-party cookies</h2>
        <p>Some of the cookies used on our website may be set by third parties, such as analytics providers or advertising networks. We do not have control over these cookies and you should check the respective third-party websites for more information about their cookie policies.</p>
      </div>
    </div>
  );
}
