import SEO from '../../components/seo/SEO';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <SEO title="Privacy Policy - QuickTools" description="Read our privacy policy to understand how we protect your data." />
      <div className="max-w-3xl mx-auto prose prose-slate">
        <h1>Privacy Policy</h1>
        <p>Last updated: January 2026</p>
        
        <h2>1. Introduction</h2>
        <p>Welcome to QuickTools ("we," "our," or "us"). We are committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your information when you use our website.</p>
        
        <h2>2. Data Processing (Client-Side)</h2>
        <p>A core principle of QuickTools is privacy by design. The majority of our tools, including image compression, resizing, and PDF conversion, process your files entirely on your device (client-side). Your files are not uploaded to our servers unless explicitly stated otherwise on the specific tool's page.</p>

        <h2>3. Information We Collect</h2>
        <p>When you visit QuickTools, we may collect the following information:</p>
        <ul>
          <li><strong>Usage Data:</strong> We may use analytics services to collect anonymous data about how you interact with our website (e.g., pages visited, time spent, tools used) to improve our services.</li>
          <li><strong>Cookies:</strong> We use cookies to enhance your experience and serve relevant advertisements. See our Cookie Policy for more details.</li>
        </ul>

        <h2>4. Advertising</h2>
        <p>We use third-party advertising companies, such as Google AdSense, to serve ads when you visit our website. These companies may use information (not including your name, address, email address, or telephone number) about your visits to this and other websites in order to provide advertisements about goods and services of interest to you.</p>

        <h2>5. Your Rights</h2>
        <p>You have the right to:</p>
        <ul>
          <li>Opt-out of certain analytics and advertising cookies.</li>
          <li>Request information about the data we hold about you (which is typically anonymous usage data).</li>
        </ul>

        <h2>6. Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us via our Contact page.</p>
      </div>
    </div>
  );
}
