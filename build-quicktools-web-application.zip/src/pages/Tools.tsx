import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import SEO from '../components/seo/SEO';
import AdSlot from '../components/ads/AdSlot';
import ToolCard from '../components/tools/ToolCard';
import { toolsData, Category } from '../data/toolsData';

const CATEGORIES: { label: string; value: Category | 'All' }[] = [
  { label: 'All Tools', value: 'All' },
  { label: 'Image Tools', value: 'Image' },
  { label: 'PDF Tools', value: 'PDF' },
  { label: 'Calculators', value: 'Calculator' },
  { label: 'Text Tools', value: 'Text' },
  { label: 'Generators', value: 'Generator' }
];

export default function Tools() {
  const [searchParams, setSearchParams] = useSearchParams();
  const queryParam = searchParams.get('q') || '';
  const categoryParam = searchParams.get('category') || 'All';
  
  const [searchQuery, setSearchQuery] = useState(queryParam);
  const [activeCategory, setActiveCategory] = useState<Category | 'All'>(
    (CATEGORIES.find(c => c.value.toLowerCase() === categoryParam.toLowerCase())?.value as Category | 'All') || 'All'
  );

  useEffect(() => {
    setSearchQuery(queryParam);
  }, [queryParam]);

  const filteredTools = toolsData.filter(tool => {
    const matchesSearch = tool.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          tool.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'All' || tool.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCategoryChange = (category: Category | 'All') => {
    setActiveCategory(category);
    if (category === 'All') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', category.toLowerCase());
    }
    setSearchParams(searchParams);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    if (value) {
      searchParams.set('q', value);
    } else {
      searchParams.delete('q');
    }
    setSearchParams(searchParams, { replace: true });
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <SEO 
        title="All Tools - QuickTools"
        description="Browse our collection of free online tools for images, PDFs, text, and calculations."
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">All Tools</h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Everything you need, in one place. Fast, free and easy to use.
          </p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 md:p-6 mb-12">
          <div className="relative max-w-2xl mx-auto mb-8">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search for a tool..."
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all outline-none"
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2">
            {CATEGORIES.map(category => (
              <button
                key={category.value}
                onClick={() => handleCategoryChange(category.value)}
                className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeCategory === category.value
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>

        <AdSlot className="mb-12" />

        {/* Tools Grid */}
        {filteredTools.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTools.map(tool => (
              <ToolCard key={tool.id} tool={tool} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
            <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">No tools found</h3>
            <p className="text-slate-500">We couldn't find any tools matching your search criteria.</p>
            <button 
              onClick={() => {
                setSearchQuery('');
                setActiveCategory('All');
                setSearchParams({});
              }}
              className="mt-6 text-blue-600 font-medium hover:text-blue-700"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
