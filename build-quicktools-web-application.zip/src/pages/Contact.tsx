import React, { useState } from 'react';
import { Mail, Send } from 'lucide-react';
import SEO from '../components/seo/SEO';

export default function Contact() {
  const [status, setStatus] = useState<'idle' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate sending
    setTimeout(() => {
      setStatus('success');
    }, 800);
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <SEO title="Contact Us - QuickTools" description="Get in touch with the QuickTools team for support, feedback, or inquiries." />
      <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-200 p-8 md:p-12">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <Mail className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Contact Us</h1>
          <p className="text-slate-600">
            Have a question, feedback, or a feature request? We'd love to hear from you.
            (Note: This form is a placeholder and doesn't actually send emails yet).
          </p>
        </div>

        {status === 'success' ? (
          <div className="text-center py-8 bg-green-50 rounded-xl border border-green-200">
            <h3 className="text-2xl font-semibold text-green-800 mb-2">Message Sent!</h3>
            <p className="text-green-700">Thank you for reaching out. We'll get back to you soon.</p>
            <button 
              onClick={() => setStatus('idle')}
              className="mt-6 text-green-700 font-medium hover:text-green-800 underline"
            >
              Send another message
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">Name</label>
              <input 
                type="text" 
                id="name" 
                required 
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all outline-none"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">Email</label>
              <input 
                type="email" 
                id="email" 
                required 
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all outline-none"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-1">Message</label>
              <textarea 
                id="message" 
                rows={5} 
                required 
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all outline-none resize-none"
              ></textarea>
            </div>
            <button 
              type="submit"
              className="w-full flex items-center justify-center bg-blue-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors shadow-sm"
            >
              Send Message
              <Send className="w-5 h-5 ml-2" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
