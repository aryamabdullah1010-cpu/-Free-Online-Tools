import { useState, useRef } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import { Download, X, FileOutput, ShieldCheck } from 'lucide-react';
import ToolPage from '../../components/tools/ToolPage';

// Configure pdfjs worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface PageImage {
  pageNumber: number;
  url: string;
}

export default function PdfToJpg() {
  const [file, setFile] = useState<File | null>(null);
  const [pages, setPages] = useState<PageImage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type === 'application/pdf') {
      processFile(droppedFile);
    }
  };

  const processFile = async (selectedFile: File) => {
    setFile(selectedFile);
    setPages([]);
    setIsProcessing(true);
    setProgress(0);

    try {
      const arrayBuffer = await selectedFile.arrayBuffer();
      const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;
      
      const numPages = pdf.numPages;
      const extractedPages: PageImage[] = [];

      for (let i = 1; i <= numPages; i++) {
        const page = await pdf.getPage(i);
        const scale = 2.0; // Higher scale for better quality
        const viewport = page.getViewport({ scale });

        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        if (!context) continue;

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = {
          canvasContext: context,
          viewport: viewport,
        };

        await page.render(renderContext as any).promise;

        const url = canvas.toDataURL('image/jpeg', 0.9);
        extractedPages.push({ pageNumber: i, url });
        
        setProgress(Math.round((i / numPages) * 100));
      }

      setPages(extractedPages);
    } catch (error) {
      console.error(error);
      alert('Failed to process PDF. It might be corrupted or encrypted.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = (page: PageImage) => {
    const link = document.createElement('a');
    link.href = page.url;
    link.download = `${file?.name.replace('.pdf', '')}_page-${page.pageNumber}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const clear = () => {
    setFile(null);
    setPages([]);
    setProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <ToolPage
      title="PDF to JPG"
      description="Extract pages from a PDF and save them as high-quality JPG images."
      howToSteps={[
        { title: 'Upload PDF', description: 'Select or drag & drop a PDF file.' },
        { title: 'Wait for Processing', description: 'Your browser will extract the pages automatically.' },
        { title: 'Download Images', description: 'Download individual pages as JPG files.' }
      ]}
      faqs={[
        {
          question: 'Are my PDFs uploaded to a server?',
          answer: 'No! The PDF processing happens completely locally in your browser using JavaScript. We never see your files.'
        }
      ]}
    >
      <div className="flex items-center justify-center p-4 bg-green-50 text-green-800 rounded-xl border border-green-200 mb-8">
        <ShieldCheck className="w-5 h-5 mr-2 flex-shrink-0" />
        <span className="text-sm font-medium">Your PDF is processed in your browser. Complete privacy guaranteed.</span>
      </div>

      {!file ? (
        <div 
          className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:bg-slate-50 transition-colors cursor-pointer mb-8"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleFileDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <FileOutput className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">Upload PDF Document</h3>
          <p className="text-slate-500 mb-6">Select a PDF to extract its pages</p>
          <button className="bg-slate-900 text-white px-6 py-2.5 rounded-xl font-medium hover:bg-slate-800 transition-colors pointer-events-none">
            Select PDF
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="application/pdf"
            onChange={(e) => {
              if (e.target.files?.[0]) {
                processFile(e.target.files[0]);
              }
            }}
          />
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center space-x-4 overflow-hidden">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <FileOutput className="w-6 h-6" />
              </div>
              <div className="truncate pr-4">
                <div className="font-semibold text-slate-900 truncate">{file.name}</div>
                <div className="text-sm text-slate-500">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </div>
              </div>
            </div>
            <button 
              onClick={clear}
              disabled={isProcessing}
              className="p-2 text-slate-400 hover:text-red-500 bg-white rounded-full border border-slate-200 shadow-sm flex-shrink-0 disabled:opacity-50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {isProcessing && (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center shadow-sm">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-4 border-blue-600 border-r-4 border-r-transparent mb-4"></div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Extracting Pages...</h3>
              <div className="w-full max-w-md mx-auto bg-slate-100 rounded-full h-2.5 mb-2 overflow-hidden">
                <div className="bg-blue-600 h-2.5 rounded-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
              </div>
              <p className="text-slate-500 font-medium">{progress}% Complete</p>
            </div>
          )}

          {!isProcessing && pages.length > 0 && (
            <div>
              <h3 className="text-xl font-bold text-slate-900 mb-4">Extracted Pages ({pages.length})</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {pages.map(page => (
                  <div key={page.pageNumber} className="bg-white border border-slate-200 rounded-xl p-2 shadow-sm flex flex-col hover:border-blue-300 transition-colors group">
                    <div className="relative aspect-[1/1.4] w-full bg-slate-50 mb-2 flex items-center justify-center overflow-hidden rounded-lg">
                      <img src={page.url} alt={`Page ${page.pageNumber}`} className="max-w-full max-h-full object-contain shadow-sm" />
                    </div>
                    <div className="mt-auto flex items-center justify-between px-1">
                      <span className="text-sm font-medium text-slate-700">Page {page.pageNumber}</span>
                      <button 
                        onClick={() => handleDownload(page)}
                        className="p-1.5 text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                        title="Download JPG"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </ToolPage>
  );
}
