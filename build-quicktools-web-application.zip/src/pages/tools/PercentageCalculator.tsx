import { useState } from 'react';
import ToolPage from '../../components/tools/ToolPage';

export default function PercentageCalculator() {
  // Calculator 1: What is X% of Y?
  const [calc1X, setCalc1X] = useState('');
  const [calc1Y, setCalc1Y] = useState('');
  
  // Calculator 2: X is what percent of Y?
  const [calc2X, setCalc2X] = useState('');
  const [calc2Y, setCalc2Y] = useState('');

  // Calculator 3: Percentage increase/decrease
  const [calc3X, setCalc3X] = useState('');
  const [calc3Y, setCalc3Y] = useState('');

  const renderResult = (value: number) => {
    if (isNaN(value) || !isFinite(value)) return '—';
    // Round to 2 decimal places if needed
    return Number.isInteger(value) ? value : value.toFixed(2);
  };

  const res1 = (parseFloat(calc1X) / 100) * parseFloat(calc1Y);
  const res2 = (parseFloat(calc2X) / parseFloat(calc2Y)) * 100;
  const res3 = ((parseFloat(calc3Y) - parseFloat(calc3X)) / Math.abs(parseFloat(calc3X))) * 100;

  const faqs = [
    {
      question: 'How do I calculate what percentage one number is of another?',
      answer: 'Divide the first number by the second number, then multiply by 100.'
    },
    {
      question: 'How is percentage increase calculated?',
      answer: 'Subtract the old value from the new value, divide by the absolute value of the old value, and multiply by 100.'
    }
  ];

  return (
    <ToolPage
      title="Percentage Calculator"
      description="Quickly calculate percentages, increases, decreases, and differences."
      faqs={faqs}
      howToSteps={[
        { title: 'Choose Calculator', description: 'Find the specific percentage calculator that matches your question.' },
        { title: 'Enter Numbers', description: 'Input your numbers into the fields.' },
        { title: 'Get Instant Result', description: 'The result is calculated automatically as you type.' }
      ]}
    >
      <div className="space-y-8">
        {/* Calculator 1 */}
        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4">What is X% of Y?</h3>
          <div className="flex flex-wrap items-center gap-4 text-lg font-medium text-slate-700">
            <span>What is</span>
            <input 
              type="number" 
              value={calc1X} 
              onChange={e => setCalc1X(e.target.value)} 
              className="w-24 px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
            />
            <span>% of</span>
            <input 
              type="number" 
              value={calc1Y} 
              onChange={e => setCalc1Y(e.target.value)} 
              className="w-24 px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
            />
            <span>?</span>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-200 text-xl text-slate-900">
            Result: <span className="font-bold text-blue-600">{renderResult(res1)}</span>
          </div>
        </div>

        {/* Calculator 2 */}
        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4">X is what percentage of Y?</h3>
          <div className="flex flex-wrap items-center gap-4 text-lg font-medium text-slate-700">
            <input 
              type="number" 
              value={calc2X} 
              onChange={e => setCalc2X(e.target.value)} 
              className="w-24 px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
            />
            <span>is what % of</span>
            <input 
              type="number" 
              value={calc2Y} 
              onChange={e => setCalc2Y(e.target.value)} 
              className="w-24 px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
            />
            <span>?</span>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-200 text-xl text-slate-900">
            Result: <span className="font-bold text-blue-600">{renderResult(res2)}%</span>
          </div>
        </div>

        {/* Calculator 3 */}
        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4">Percentage Increase/Decrease</h3>
          <div className="flex flex-wrap items-center gap-4 text-lg font-medium text-slate-700">
            <span>From</span>
            <input 
              type="number" 
              value={calc3X} 
              onChange={e => setCalc3X(e.target.value)} 
              className="w-24 px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
            />
            <span>to</span>
            <input 
              type="number" 
              value={calc3Y} 
              onChange={e => setCalc3Y(e.target.value)} 
              className="w-24 px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
            />
          </div>
          <div className="mt-4 pt-4 border-t border-slate-200 text-xl text-slate-900">
            Result: <span className="font-bold text-blue-600">{renderResult(Math.abs(res3))}%</span> 
            {res3 > 0 && <span className="text-green-600 ml-2 text-base font-semibold">(Increase)</span>}
            {res3 < 0 && <span className="text-red-600 ml-2 text-base font-semibold">(Decrease)</span>}
          </div>
        </div>

      </div>
    </ToolPage>
  );
}
