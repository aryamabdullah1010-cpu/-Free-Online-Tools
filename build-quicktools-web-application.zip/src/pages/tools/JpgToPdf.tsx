import { useState, useRef } from 'react';
import { PDFDocument } from 'pdf-lib';
import { Upload, X, FileUp, ShieldCheck } from 'lucide-react';
import ToolPage from '../../components/tools/ToolPage';

interface ImageItem {
  id: string;
  file: File;
  preview: string;
}

export default function JpgToPdf() {
  const [images, setImages] = useState<ImageItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    const newImages = Array.from(files)
      .filter(file => file.type.startsWith('image/'))
      .map(file => ({
        id: Math.random().toString(36).substring(7),
        file,
        preview: URL.createObjectURL(file)
      }));
    setImages(prev => [...prev, ...newImages]);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    handleFiles(e.dataTransfer.files);
  };

  const removeImage = (id: string) => {
    setImages(prev => {
      const img = prev.find(i => i.id === id);
      if (img) URL.revokeObjectURL(img.preview);
      return prev.filter(i => i.id !== id);
    });
  };

  const moveImage = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === images.length - 1) return;
    
    const newImages = [...images];
    const swapIndex = direction === 'up' ? index - 1 : index + 1;
    [newImages[index], newImages[swapIndex]] = [newImages[swapIndex], newImages[index]];
    setImages(newImages);
  };

  const generatePDF = async () => {
    if (images.length === 0) return;
    setIsProcessing(true);

    try {
      const pdfDoc = await PDFDocument.create();

      for (const imgItem of images) {
        const imageBytes = await imgItem.file.arrayBuffer();
        let pdfImage;
        
        if (imgItem.file.type === 'image/jpeg' || imgItem.file.type === 'image/jpg') {
          pdfImage = await pdfDoc.embedJpg(imageBytes);
        } else if (imgItem.file.type === 'image/png') {
          pdfImage = await pdfDoc.embedPng(imageBytes);
        } else {
          // Unsupported format by standard pdf-lib without extra conversion
          alert(`File ${imgItem.file.name} is not a valid JPG or PNG. Only JPG and PNG are supported for direct PDF embedding.`);
          continue;
        }

        const dims = pdfImage.scale(1);
        const page = pdfDoc.addPage([dims.width, dims.height]);
        page.drawImage(pdfImage, {
          x: 0,
          y: 0,
          width: dims.width,
          height: dims.height,
        });
      }

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes as unknown as BlobPart], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = `QuickTools-Images.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

    } catch (error) {
      console.error(error);
      alert('Failed to generate PDF. Make sure all images are valid JPGs or PNGs.');
    } finally {
      setIsProcessing(false);
    }
  };

  const clearAll = () => {
    images.forEach(img => URL.revokeObjectURL(img.preview));
    setImages([]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <ToolPage
      title="JPG to PDF"
      description="Convert and combine multiple JPG/PNG images into a single PDF document."
      howToSteps={[
        { title: 'Upload Images', description: 'Select or drag & drop multiple JPG or PNG images.' },
        { title: 'Reorder', description: 'Use the up/down arrows to arrange the images in the desired order.' },
        { title: 'Generate PDF', description: 'Click generate and your PDF will be created directly in your browser.' }
      ]}
      faqs={[
        {
          question: 'Are my images safe?',
          answer: 'Yes. The PDF is generated entirely locally in your web browser. No files are uploaded to our servers.'
        }
      ]}
    >
      <div className="flex items-center justify-center p-4 bg-green-50 text-green-800 rounded-xl border border-green-200 mb-8">
        <ShieldCheck className="w-5 h-5 mr-2 flex-shrink-0" />
        <span className="text-sm font-medium">Your files are processed in your browser. Complete privacy guaranteed.</span>
      </div>

      <div 
        className="border-2 border-dashed border-slate-300 rounded-2xl p-8 md:p-12 text-center hover:bg-slate-50 transition-colors cursor-pointer mb-8"
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Upload className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-slate-900 mb-2">Upload Images (JPG, PNG)</h3>
        <p className="text-slate-500 mb-6">Select multiple files at once</p>
        <button className="bg-slate-900 text-white px-6 py-2.5 rounded-xl font-medium hover:bg-slate-800 transition-colors pointer-events-none">
          Select Files
        </button>
        <input 
          type="file" 
          multiple
          ref={fileInputRef} 
          className="hidden" 
          accept="image/jpeg, image/png"
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>

      {images.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-6 border-b border-slate-200 pb-4">
            <h3 className="text-lg font-bold text-slate-900">
              Selected Images ({images.length})
            </h3>
            <button 
              onClick={clearAll}
              className="text-red-500 hover:text-red-700 text-sm font-medium"
            >
              Clear All
            </button>
          </div>

          <div className="space-y-3 mb-8 max-h-[400px] overflow-y-auto pr-2">
            {images.map((img, index) => (
              <div key={img.id} className="flex items-center gap-4 bg-slate-50 p-3 rounded-xl border border-slate-200 group">
                <div className="flex flex-col gap-1">
                  <button 
                    onClick={() => moveImage(index, 'up')}
                    disabled={index === 0}
                    className="p-1 text-slate-400 hover:text-blue-600 disabled:opacity-30 disabled:hover:text-slate-400"
                  >
                    ▲
                  </button>
                  <button 
                    onClick={() => moveImage(index, 'down')}
                    disabled={index === images.length - 1}
                    className="p-1 text-slate-400 hover:text-blue-600 disabled:opacity-30 disabled:hover:text-slate-400"
                  >
                    ▼
                  </button>
                </div>
                
                <div className="w-16 h-16 rounded-lg overflow-hidden bg-white border border-slate-200 flex-shrink-0 flex items-center justify-center">
                  <img src={img.preview} alt="preview" className="max-w-full max-h-full object-contain" />
                </div>
                
                <div className="flex-grow min-w-0">
                  <p className="font-medium text-slate-900 truncate">{img.file.name}</p>
                  <p className="text-xs text-slate-500">{(img.file.size / 1024).toFixed(1)} KB</p>
                </div>

                <button 
                  onClick={() => removeImage(img.id)}
                  className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors flex-shrink-0"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>

          <button 
            onClick={generatePDF}
            disabled={isProcessing}
            className="w-full flex items-center justify-center bg-blue-600 text-white px-6 py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50"
          >
            {isProcessing ? 'Generating PDF...' : (
              <>
                <FileUp className="w-5 h-5 mr-2" /> Combine into PDF
              </>
            )}
          </button>
        </div>
      )}
    </ToolPage>
  );
}
