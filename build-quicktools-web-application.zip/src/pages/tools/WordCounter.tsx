import { useState, useMemo } from 'react';
import ToolPage from '../../components/tools/ToolPage';

export default function WordCounter() {
  const [text, setText] = useState('');

  const stats = useMemo(() => {
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    const characters = text.length;
    const charactersNoSpaces = text.replace(/\s+/g, '').length;
    const sentences = text.trim() ? text.split(/[.!?]+/).filter(Boolean).length : 0;
    const paragraphs = text.trim() ? text.split(/\n+/).filter(Boolean).length : 0;
    const readingTime = Math.ceil(words / 200); // Average reading speed ~200 wpm

    return { words, characters, charactersNoSpaces, sentences, paragraphs, readingTime };
  }, [text]);

  const handleClear = () => setText('');
  
  const handleCopy = () => {
    navigator.clipboard.writeText(text);
  };

  const faqs = [
    {
      question: 'Is my text sent to a server?',
      answer: 'No. The word counting process happens entirely in your web browser. Your text is completely private and never leaves your device.'
    },
    {
      question: 'How is reading time calculated?',
      answer: 'Reading time is estimated based on an average reading speed of 200 words per minute.'
    }
  ];

  return (
    <ToolPage
      title="Word Counter"
      description="Instantly count words, characters, sentences, and paragraphs in your text."
      faqs={faqs}
      howToSteps={[
        { title: 'Type or Paste Text', description: 'Enter your text into the large text area.' },
        { title: 'View Live Stats', description: 'Watch the word count and other statistics update instantly as you type.' },
        { title: 'Copy or Clear', description: 'Use the handy buttons to copy your text or clear the area to start over.' }
      ]}
      relatedTools={[]} // Could add others if needed
    >
      <div className="space-y-6">
        {/* Statistics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-1">{stats.words}</div>
            <div className="text-sm font-medium text-slate-600 uppercase tracking-wide">Words</div>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-1">{stats.characters}</div>
            <div className="text-sm font-medium text-slate-600 uppercase tracking-wide">Characters</div>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-1">{stats.charactersNoSpaces}</div>
            <div className="text-sm font-medium text-slate-600 uppercase tracking-wide">Chars (no spaces)</div>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-1">{stats.sentences}</div>
            <div className="text-sm font-medium text-slate-600 uppercase tracking-wide">Sentences</div>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-1">{stats.paragraphs}</div>
            <div className="text-sm font-medium text-slate-600 uppercase tracking-wide">Paragraphs</div>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-1">{stats.readingTime}m</div>
            <div className="text-sm font-medium text-slate-600 uppercase tracking-wide">Reading Time</div>
          </div>
        </div>

        {/* Text Area */}
        <div className="relative">
          <textarea
            className="w-full h-64 p-4 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all outline-none resize-y"
            placeholder="Type or paste your text here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          ></textarea>
        </div>

        {/* Actions */}
        <div className="flex gap-4">
          <button
            onClick={handleCopy}
            className="flex-1 bg-slate-900 text-white px-6 py-3 rounded-xl font-medium hover:bg-slate-800 transition-colors shadow-sm"
          >
            Copy Text
          </button>
          <button
            onClick={handleClear}
            className="flex-1 bg-slate-100 text-slate-700 px-6 py-3 rounded-xl font-medium hover:bg-slate-200 transition-colors"
          >
            Clear Text
          </button>
        </div>
      </div>
    </ToolPage>
  );
}
