import { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Download, RefreshCw } from 'lucide-react';
import ToolPage from '../../components/tools/ToolPage';

export default function QrCodeGenerator() {
  const [text, setText] = useState('https://quicktools.com');
  const [qrUrl, setQrUrl] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    generateQR();
  }, [text]);

  const generateQR = async () => {
    try {
      if (!text.trim()) {
        setQrUrl('');
        setError('Please enter some text or a URL');
        return;
      }
      
      setError('');
      const url = await QRCode.toDataURL(text, {
        width: 400,
        margin: 2,
        color: {
          dark: '#0f172a', // slate-900
          light: '#ffffff'
        }
      });
      setQrUrl(url);
    } catch (err) {
      console.error(err);
      setError('Could not generate QR code');
    }
  };

  const handleDownload = () => {
    if (!qrUrl) return;
    const link = document.createElement('a');
    link.href = qrUrl;
    link.download = 'qrcode.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const clear = () => setText('');

  return (
    <ToolPage
      title="QR Code Generator"
      description="Create customizable QR codes for links, text, emails, and more instantly."
      howToSteps={[
        { title: 'Enter Content', description: 'Type or paste a URL, email, or plain text into the input field.' },
        { title: 'Preview', description: 'The QR code updates live as you type.' },
        { title: 'Download', description: 'Click download to save the generated QR code as a PNG image.' }
      ]}
    >
      <div className="flex flex-col md:flex-row gap-8 items-start">
        
        {/* Input Area */}
        <div className="w-full md:w-1/2 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">URL or Text</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter text or URL here..."
              rows={5}
              className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all outline-none resize-none"
            ></textarea>
            {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
          </div>

          <button 
            onClick={clear}
            className="flex items-center text-slate-500 hover:text-slate-800 text-sm font-medium transition-colors"
          >
            <RefreshCw className="w-4 h-4 mr-1" /> Clear Input
          </button>
        </div>

        {/* Output Area */}
        <div className="w-full md:w-1/2 flex flex-col items-center bg-slate-50 p-8 rounded-2xl border border-slate-200">
          <div className="bg-white p-4 rounded-xl shadow-sm mb-6 min-h-[200px] min-w-[200px] flex items-center justify-center">
            {qrUrl ? (
              <img src={qrUrl} alt="Generated QR Code" className="w-48 h-48 md:w-64 md:h-64 object-contain" />
            ) : (
              <div className="text-slate-400 text-sm">Preview will appear here</div>
            )}
          </div>
          
          <button
            onClick={handleDownload}
            disabled={!qrUrl}
            className="w-full max-w-[256px] flex items-center justify-center bg-blue-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Download className="w-5 h-5 mr-2" /> Download PNG
          </button>
        </div>
      </div>
    </ToolPage>
  );
}
