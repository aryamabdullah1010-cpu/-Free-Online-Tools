import { useState, useRef, useEffect } from 'react';
import { Upload, Download, Lock, Unlock, X } from 'lucide-react';
import ToolPage from '../../components/tools/ToolPage';

const PRESETS = [
  { name: 'Custom', width: 0, height: 0 },
  { name: 'Instagram Square', width: 1080, height: 1080 },
  { name: 'Instagram Portrait', width: 1080, height: 1350 },
  { name: 'YouTube Thumbnail', width: 1280, height: 720 },
  { name: 'Facebook Post', width: 1200, height: 630 },
  { name: 'Twitter Post', width: 1600, height: 900 }
];

export default function ImageResizer() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  
  const [width, setWidth] = useState<number | ''>('');
  const [height, setHeight] = useState<number | ''>('');
  const [maintainAspect, setMaintainAspect] = useState(true);
  const [originalAspect, setOriginalAspect] = useState(1);
  const [preset, setPreset] = useState('Custom');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    if (file) {
      const url = URL.createObjectURL(file);
      setPreview(url);
      
      const img = new Image();
      img.onload = () => {
        setWidth(img.width);
        setHeight(img.height);
        setOriginalAspect(img.width / img.height);
      };
      img.src = url;

      return () => URL.revokeObjectURL(url);
    } else {
      setPreview('');
      setWidth('');
      setHeight('');
    }
  }, [file]);

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type.startsWith('image/')) {
      setFile(droppedFile);
      setPreset('Custom');
    }
  };

  const handleWidthChange = (val: string) => {
    const num = parseInt(val, 10);
    setWidth(isNaN(num) ? '' : num);
    if (maintainAspect && !isNaN(num)) {
      setHeight(Math.round(num / originalAspect));
    }
    setPreset('Custom');
  };

  const handleHeightChange = (val: string) => {
    const num = parseInt(val, 10);
    setHeight(isNaN(num) ? '' : num);
    if (maintainAspect && !isNaN(num)) {
      setWidth(Math.round(num * originalAspect));
    }
    setPreset('Custom');
  };

  const applyPreset = (presetName: string) => {
    setPreset(presetName);
    const p = PRESETS.find(p => p.name === presetName);
    if (p && p.width && p.height) {
      setWidth(p.width);
      setHeight(p.height);
      if (maintainAspect) {
        setMaintainAspect(false); // Disable to allow non-matching presets
      }
    }
  };

  const handleDownload = () => {
    if (!file || !width || !height) return;

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = Number(width);
      canvas.height = Number(height);
      
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      // Draw image
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      
      // Download
      canvas.toBlob((blob) => {
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `resized-${file.name}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, file.type);
    };
    img.src = preview;
  };

  const clear = () => {
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <ToolPage
      title="Image Resizer"
      description="Resize images easily online. Change dimensions or use presets for social media."
      howToSteps={[
        { title: 'Upload Image', description: 'Drag and drop or select an image file.' },
        { title: 'Set Dimensions', description: 'Enter new width/height or choose a social media preset.' },
        { title: 'Download', description: 'Click download to save the resized image. Processed entirely in your browser.' }
      ]}
      faqs={[
        {
          question: 'Are my images uploaded to a server?',
          answer: 'No, this tool resizes your images entirely in your web browser. Your files never leave your device, ensuring complete privacy.'
        }
      ]}
    >
      {!file ? (
        <div 
          className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:bg-slate-50 hover:border-blue-400 transition-colors cursor-pointer"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleFileDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Upload className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">Upload Image</h3>
          <p className="text-slate-500 mb-6">Drag and drop an image here, or click to select</p>
          <button className="bg-slate-900 text-white px-6 py-2.5 rounded-xl font-medium hover:bg-slate-800 transition-colors">
            Select File
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/*"
            onChange={(e) => {
              if (e.target.files?.[0]) setFile(e.target.files[0]);
            }}
          />
        </div>
      ) : (
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Image Preview */}
          <div className="w-full lg:w-1/2 flex flex-col items-center bg-slate-50 p-4 rounded-2xl border border-slate-200 relative">
            <button 
              onClick={clear}
              className="absolute top-2 right-2 p-2 bg-white rounded-full text-slate-500 hover:text-red-500 hover:bg-red-50 shadow-sm transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex-grow flex items-center justify-center w-full min-h-[300px] overflow-hidden rounded-xl border border-slate-200 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCI+CjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0iI2ZmZiI+PC9yZWN0Pgo8cmVjdCB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIGZpbGw9IiNlNWU1ZTUiPjwvcmVjdD4KPHJlY3QgeD0iMTAiIHk9IjEwIiB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIGZpbGw9IiNlNWU1ZTUiPjwvcmVjdD4KPC9zdmc+')]">
              <img ref={imgRef} src={preview} alt="Preview" className="max-w-full max-h-[400px] object-contain" />
            </div>
            <div className="mt-4 text-sm font-medium text-slate-600">
              Original: {imgRef.current?.naturalWidth} × {imgRef.current?.naturalHeight}
            </div>
          </div>

          {/* Controls */}
          <div className="w-full lg:w-1/2 space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Presets</label>
              <select 
                value={preset}
                onChange={(e) => applyPreset(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
              >
                {PRESETS.map(p => (
                  <option key={p.name} value={p.name}>{p.name} {p.width ? `(${p.width}×${p.height})` : ''}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-slate-700 mb-2">Width (px)</label>
                <input 
                  type="number" 
                  value={width}
                  onChange={(e) => handleWidthChange(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
                />
              </div>
              <div className="flex flex-col items-center justify-center mt-6">
                <button 
                  onClick={() => setMaintainAspect(!maintainAspect)}
                  className={`p-2 rounded-lg transition-colors ${maintainAspect ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`}
                  title={maintainAspect ? "Unlock aspect ratio" : "Lock aspect ratio"}
                >
                  {maintainAspect ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
                </button>
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium text-slate-700 mb-2">Height (px)</label>
                <input 
                  type="number" 
                  value={height}
                  onChange={(e) => handleHeightChange(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
                />
              </div>
            </div>

            <button 
              onClick={handleDownload}
              className="w-full flex items-center justify-center bg-blue-600 text-white px-6 py-3.5 rounded-xl font-semibold text-lg hover:bg-blue-700 transition-colors shadow-sm"
            >
              <Download className="w-6 h-6 mr-2" />
              Download Resized Image
            </button>
          </div>
        </div>
      )}
    </ToolPage>
  );
}
