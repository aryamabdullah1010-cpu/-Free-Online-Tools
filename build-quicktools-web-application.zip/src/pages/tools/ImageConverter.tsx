import { useState, useRef, useEffect } from 'react';
import { Upload, Download, ArrowRightLeft, X } from 'lucide-react';
import ToolPage from '../../components/tools/ToolPage';

export default function ImageConverter() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [targetFormat, setTargetFormat] = useState('image/png');
  const [quality, setQuality] = useState(0.9);
  const [isConverting, setIsConverting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (file) {
      const url = URL.createObjectURL(file);
      setPreview(url);
      
      // Auto-select a different format than the original
      if (file.type === 'image/jpeg') setTargetFormat('image/png');
      else if (file.type === 'image/png') setTargetFormat('image/jpeg');
      else if (file.type === 'image/webp') setTargetFormat('image/jpeg');
      
      return () => URL.revokeObjectURL(url);
    } else {
      setPreview('');
    }
  }, [file]);

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type.startsWith('image/')) {
      setFile(droppedFile);
    }
  };

  const handleDownload = () => {
    if (!file) return;
    setIsConverting(true);

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // If converting to JPEG, fill with white background first (since JPEG doesn't support transparency)
      if (targetFormat === 'image/jpeg') {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      
      ctx.drawImage(img, 0, 0);
      
      canvas.toBlob((blob) => {
        if (!blob) {
          setIsConverting(false);
          return;
        }
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        
        const ext = targetFormat.split('/')[1];
        const originalName = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
        a.download = `${originalName}-converted.${ext}`;
        
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setIsConverting(false);
      }, targetFormat, quality);
    };
    img.src = preview;
  };

  const clear = () => {
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <ToolPage
      title="Image Converter"
      description="Convert images between JPG, PNG, and WebP formats instantly."
      howToSteps={[
        { title: 'Upload Image', description: 'Select the image you want to convert.' },
        { title: 'Choose Format', description: 'Select your desired output format (JPG, PNG, or WebP).' },
        { title: 'Download', description: 'Get your converted image immediately without server uploads.' }
      ]}
      faqs={[
        {
          question: 'Are my images private?',
          answer: 'Yes! The conversion happens entirely in your browser using the HTML5 Canvas API. Your images are never sent to a server.'
        },
        {
          question: 'Why did my PNG lose transparency when converted to JPG?',
          answer: 'The JPG format does not support transparency. When you convert a transparent PNG to JPG, the transparent areas are automatically filled with white.'
        }
      ]}
    >
      {!file ? (
        <div 
          className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:bg-slate-50 hover:border-blue-400 transition-colors cursor-pointer"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleFileDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Upload className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">Upload Image to Convert</h3>
          <p className="text-slate-500 mb-6">Supports JPG, PNG, WebP</p>
          <button className="bg-slate-900 text-white px-6 py-2.5 rounded-xl font-medium hover:bg-slate-800 transition-colors">
            Select File
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/jpeg, image/png, image/webp"
            onChange={(e) => {
              if (e.target.files?.[0]) setFile(e.target.files[0]);
            }}
          />
        </div>
      ) : (
        <div className="flex flex-col md:flex-row gap-8 items-center bg-slate-50 p-6 rounded-2xl border border-slate-200">
          {/* Image Preview */}
          <div className="w-full md:w-1/3 flex flex-col items-center">
            <div className="relative w-full aspect-square bg-white rounded-xl border border-slate-200 overflow-hidden flex items-center justify-center bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCI+CjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0iI2ZmZiI+PC9yZWN0Pgo8cmVjdCB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIGZpbGw9IiNlNWU1ZTUiPjwvcmVjdD4KPHJlY3QgeD0iMTAiIHk9IjEwIiB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIGZpbGw9IiNlNWU1ZTUiPjwvcmVjdD4KPC9zdmc+')]">
              <img src={preview} alt="Original" className="max-w-full max-h-full object-contain" />
              <button 
                onClick={clear}
                className="absolute top-2 right-2 p-1.5 bg-white rounded-full text-slate-500 hover:text-red-500 hover:bg-red-50 shadow-sm transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="mt-3 text-sm font-medium text-slate-600 bg-white px-3 py-1 rounded-full border border-slate-200 shadow-sm">
              Original: {file.type.split('/')[1].toUpperCase()}
            </div>
          </div>

          <div className="text-slate-400 hidden md:block">
            <ArrowRightLeft className="w-8 h-8" />
          </div>

          {/* Conversion Options */}
          <div className="w-full md:w-1/3 space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Convert to Format</label>
              <select 
                value={targetFormat}
                onChange={(e) => setTargetFormat(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none font-medium"
              >
                <option value="image/jpeg">JPG</option>
                <option value="image/png">PNG</option>
                <option value="image/webp">WebP</option>
              </select>
            </div>

            {(targetFormat === 'image/jpeg' || targetFormat === 'image/webp') && (
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-slate-700">Quality</label>
                  <span className="text-sm text-slate-500">{Math.round(quality * 100)}%</span>
                </div>
                <input 
                  type="range" 
                  min="0.1" 
                  max="1" 
                  step="0.1" 
                  value={quality} 
                  onChange={(e) => setQuality(parseFloat(e.target.value))}
                  className="w-full accent-blue-600"
                />
              </div>
            )}

            <button 
              onClick={handleDownload}
              disabled={isConverting}
              className="w-full flex items-center justify-center bg-blue-600 text-white px-6 py-3.5 rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isConverting ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Converting...
                </span>
              ) : (
                <>
                  <Download className="w-5 h-5 mr-2" /> Download Converted File
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </ToolPage>
  );
}
