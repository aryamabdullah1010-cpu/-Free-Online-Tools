import { useState } from 'react';
import { Plus, Trash2, RotateCcw } from 'lucide-react';
import ToolPage from '../../components/tools/ToolPage';

interface Course {
  id: number;
  name: string;
  credits: string;
  grade: string;
}

const GRADE_VALUES_4: Record<string, number> = {
  'A+': 4.0, 'A': 4.0, 'A-': 3.7,
  'B+': 3.3, 'B': 3.0, 'B-': 2.7,
  'C+': 2.3, 'C': 2.0, 'C-': 1.7,
  'D+': 1.3, 'D': 1.0, 'F': 0.0
};

const GRADE_VALUES_5: Record<string, number> = {
  'A+': 5.0, 'A': 5.0, 'A-': 4.7,
  'B+': 4.3, 'B': 4.0, 'B-': 3.7,
  'C+': 3.3, 'C': 3.0, 'C-': 2.7,
  'D+': 2.3, 'D': 2.0, 'F': 0.0
};

export default function GpaCalculator() {
  const [scale, setScale] = useState<'4.0' | '5.0'>('4.0');
  const [courses, setCourses] = useState<Course[]>([
    { id: 1, name: 'Course 1', credits: '3', grade: 'A' },
    { id: 2, name: 'Course 2', credits: '3', grade: 'B' },
    { id: 3, name: 'Course 3', credits: '4', grade: 'A' },
  ]);

  const addCourse = () => {
    setCourses([...courses, { id: Date.now(), name: `Course ${courses.length + 1}`, credits: '3', grade: 'A' }]);
  };

  const updateCourse = (id: number, field: keyof Course, value: string) => {
    setCourses(courses.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  const removeCourse = (id: number) => {
    setCourses(courses.filter(c => c.id !== id));
  };

  const reset = () => {
    setCourses([{ id: 1, name: 'Course 1', credits: '3', grade: 'A' }]);
  };

  const gradeValues = scale === '4.0' ? GRADE_VALUES_4 : GRADE_VALUES_5;

  let totalCredits = 0;
  let totalPoints = 0;

  courses.forEach(c => {
    const cred = parseFloat(c.credits);
    if (!isNaN(cred) && c.grade && gradeValues[c.grade] !== undefined) {
      totalCredits += cred;
      totalPoints += cred * gradeValues[c.grade];
    }
  });

  const gpa = totalCredits > 0 ? (totalPoints / totalCredits).toFixed(2) : '0.00';

  return (
    <ToolPage
      title="GPA Calculator"
      description="Calculate your semester or cumulative GPA easily. Supports 4.0 and 5.0 scales."
      faqs={[
        {
          question: 'Are grading systems standard?',
          answer: 'No. While we use the most common 4.0 and 5.0 scale mappings, different institutions may assign slightly different numerical values to letter grades (for example, an A+ might be 4.3 at some schools). Always verify with your institution\'s specific policy.'
        }
      ]}
      howToSteps={[
        { title: 'Select Scale', description: 'Choose whether your school uses a 4.0 or 5.0 grading scale.' },
        { title: 'Enter Courses', description: 'Input your course names, credits/hours, and the letter grade you received.' },
        { title: 'Get GPA', description: 'Your GPA is calculated automatically as you add or update courses.' }
      ]}
    >
      <div className="mb-6 flex justify-between items-center bg-slate-50 p-4 rounded-xl border border-slate-200">
        <div>
          <label className="text-sm font-medium text-slate-700 mr-4">Grading Scale:</label>
          <select 
            value={scale} 
            onChange={(e) => setScale(e.target.value as '4.0' | '5.0')}
            className="px-3 py-1.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 outline-none"
          >
            <option value="4.0">4.0 Scale</option>
            <option value="5.0">5.0 Scale</option>
          </select>
        </div>
        <button 
          onClick={reset}
          className="text-slate-500 hover:text-red-600 flex items-center text-sm font-medium transition-colors"
        >
          <RotateCcw className="w-4 h-4 mr-1" /> Reset
        </button>
      </div>

      <div className="space-y-4 mb-8">
        <div className="grid grid-cols-12 gap-4 px-4 text-sm font-medium text-slate-500 hidden sm:grid">
          <div className="col-span-5">Course Name</div>
          <div className="col-span-3">Credits</div>
          <div className="col-span-3">Grade</div>
          <div className="col-span-1"></div>
        </div>

        {courses.map(course => (
          <div key={course.id} className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center bg-white p-4 sm:p-0 rounded-xl sm:rounded-none border border-slate-200 sm:border-none shadow-sm sm:shadow-none">
            <div className="col-span-1 sm:col-span-5">
              <label className="block text-xs text-slate-500 mb-1 sm:hidden">Course Name</label>
              <input 
                type="text" 
                value={course.name} 
                onChange={(e) => updateCourse(course.id, 'name', e.target.value)}
                placeholder="Course Name"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
              />
            </div>
            <div className="col-span-1 sm:col-span-3">
              <label className="block text-xs text-slate-500 mb-1 sm:hidden">Credits</label>
              <input 
                type="number" 
                min="0"
                step="0.5"
                value={course.credits} 
                onChange={(e) => updateCourse(course.id, 'credits', e.target.value)}
                placeholder="Credits"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
              />
            </div>
            <div className="col-span-1 sm:col-span-3">
              <label className="block text-xs text-slate-500 mb-1 sm:hidden">Grade</label>
              <select
                value={course.grade}
                onChange={(e) => updateCourse(course.id, 'grade', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none bg-white"
              >
                {Object.keys(gradeValues).map(g => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>
            </div>
            <div className="col-span-1 flex justify-end">
              <button 
                onClick={() => removeCourse(course.id)}
                className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                title="Remove course"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <button 
        onClick={addCourse}
        className="mb-8 flex items-center text-blue-600 font-medium hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-4 py-2 rounded-lg transition-colors"
      >
        <Plus className="w-5 h-5 mr-1" /> Add Course
      </button>

      <div className="bg-slate-900 text-white p-8 rounded-2xl flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left">
          <div className="text-slate-400 text-sm font-medium uppercase tracking-wider mb-1">Total Credits</div>
          <div className="text-3xl font-bold">{totalCredits}</div>
        </div>
        <div className="w-px h-12 bg-slate-700 hidden md:block"></div>
        <div className="text-center md:text-right">
          <div className="text-slate-400 text-sm font-medium uppercase tracking-wider mb-1">Your GPA</div>
          <div className="text-5xl font-black text-blue-400">{gpa}</div>
        </div>
      </div>
    </ToolPage>
  );
}
