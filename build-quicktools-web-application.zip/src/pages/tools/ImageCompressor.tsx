import { useState, useRef } from 'react';
import imageCompression from 'browser-image-compression';
import { Upload, Download, X, Settings2, ShieldCheck } from 'lucide-react';
import ToolPage from '../../components/tools/ToolPage';

export default function ImageCompressor() {
  const [file, setFile] = useState<File | null>(null);
  const [compressedFile, setCompressedFile] = useState<File | null>(null);
  const [isCompressing, setIsCompressing] = useState(false);
  
  // Target sizes in MB
  const [targetSizeMB, setTargetSizeMB] = useState<number>(1);
  const [maxWidthOrHeight, setMaxWidthOrHeight] = useState<number>(1920);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type.startsWith('image/')) {
      setFile(droppedFile);
      setCompressedFile(null);
    }
  };

  const handleCompress = async () => {
    if (!file) return;
    setIsCompressing(true);
    setCompressedFile(null);

    const options = {
      maxSizeMB: targetSizeMB,
      maxWidthOrHeight: maxWidthOrHeight,
      useWebWorker: true,
      initialQuality: 0.8
    };

    try {
      const compressed = await imageCompression(file, options);
      setCompressedFile(compressed);
    } catch (error) {
      console.error(error);
      alert('Error compressing image.');
    } finally {
      setIsCompressing(false);
    }
  };

  const handleDownload = () => {
    if (!compressedFile) return;
    const url = URL.createObjectURL(compressedFile);
    const a = document.createElement('a');
    a.href = url;
    a.download = `compressed-${file?.name || 'image.jpg'}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const clear = () => {
    setFile(null);
    setCompressedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <ToolPage
      title="Image Compressor"
      description="Reduce image file size while preserving quality. Processes entirely in your browser."
      howToSteps={[
        { title: 'Upload Image', description: 'Select or drag & drop your JPG, PNG, or WebP image.' },
        { title: 'Choose Compression', description: 'Adjust the target file size and max dimensions.' },
        { title: 'Compress & Download', description: 'Click compress and download your optimized image.' }
      ]}
      faqs={[
        {
          question: 'Are my images secure?',
          answer: 'Absolutely. All compression is performed locally in your web browser using Web Workers. Your images are never uploaded to a server.'
        },
        {
          question: 'Will my image lose quality?',
          answer: 'Our algorithm tries to find the best balance between size and quality. You may notice minor detail loss on high compression settings, but it is generally imperceptible for standard web use.'
        }
      ]}
    >
      <div className="flex items-center justify-center p-4 bg-green-50 text-green-800 rounded-xl border border-green-200 mb-8">
        <ShieldCheck className="w-5 h-5 mr-2" />
        <span className="text-sm font-medium">Your image is processed in your browser. No files are uploaded to our servers.</span>
      </div>

      {!file ? (
        <div 
          className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:bg-slate-50 hover:border-blue-400 transition-colors cursor-pointer"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleFileDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Upload className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">Upload Image to Compress</h3>
          <p className="text-slate-500 mb-6">Supports JPG, PNG, WebP (Max ~50MB)</p>
          <button className="bg-slate-900 text-white px-6 py-2.5 rounded-xl font-medium hover:bg-slate-800 transition-colors">
            Select File
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/jpeg, image/png, image/webp"
            onChange={(e) => {
              if (e.target.files?.[0]) {
                setFile(e.target.files[0]);
                setCompressedFile(null);
              }
            }}
          />
        </div>
      ) : (
        <div className="space-y-6">
          {/* File Info */}
          <div className="flex items-center justify-between bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center space-x-4 overflow-hidden">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Upload className="w-6 h-6" />
              </div>
              <div className="truncate pr-4">
                <div className="font-semibold text-slate-900 truncate">{file.name}</div>
                <div className="text-sm text-slate-500">{formatSize(file.size)}</div>
              </div>
            </div>
            <button 
              onClick={clear}
              className="p-2 text-slate-400 hover:text-red-500 bg-white rounded-full border border-slate-200 shadow-sm flex-shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Options */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <h3 className="flex items-center text-lg font-bold text-slate-900 mb-6">
              <Settings2 className="w-5 h-5 mr-2 text-slate-400" />
              Compression Settings
            </h3>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-slate-700">Target File Size</label>
                  <span className="text-sm font-bold text-blue-600">
                    {targetSizeMB >= 1 ? `${targetSizeMB} MB` : `${targetSizeMB * 1000} KB`}
                  </span>
                </div>
                <input 
                  type="range" 
                  min="0.1" 
                  max="5" 
                  step="0.1" 
                  value={targetSizeMB} 
                  onChange={(e) => setTargetSizeMB(parseFloat(e.target.value))}
                  className="w-full accent-blue-600"
                />
                <div className="flex justify-between text-xs text-slate-400 mt-1">
                  <span>100 KB</span>
                  <span>5 MB</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Max Width / Height</label>
                <select 
                  value={maxWidthOrHeight}
                  onChange={(e) => setMaxWidthOrHeight(parseInt(e.target.value))}
                  className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 outline-none bg-slate-50"
                >
                  <option value={1920}>1920px (HD)</option>
                  <option value={1280}>1280px</option>
                  <option value={1080}>1080px</option>
                  <option value={800}>800px</option>
                  <option value={4000}>Keep Original</option>
                </select>
              </div>
            </div>

            <div className="mt-8 flex justify-center">
              {!compressedFile && (
                <button 
                  onClick={handleCompress}
                  disabled={isCompressing}
                  className="w-full md:w-auto px-8 py-3.5 bg-blue-600 text-white rounded-xl font-bold text-lg hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50 flex items-center justify-center min-w-[200px]"
                >
                  {isCompressing ? 'Compressing...' : 'Compress Image'}
                </button>
              )}
            </div>
          </div>

          {/* Results */}
          {compressedFile && (
            <div className="bg-green-50 border border-green-200 rounded-2xl p-6 text-center animate-in fade-in zoom-in duration-300">
              <h3 className="text-xl font-bold text-green-800 mb-4">Compression Complete!</h3>
              
              <div className="flex justify-center items-center gap-8 mb-6">
                <div>
                  <div className="text-sm text-green-600 uppercase tracking-wide font-semibold mb-1">Original Size</div>
                  <div className="text-2xl font-bold text-slate-700">{formatSize(file.size)}</div>
                </div>
                <div className="text-green-300 text-3xl">→</div>
                <div>
                  <div className="text-sm text-green-600 uppercase tracking-wide font-semibold mb-1">New Size</div>
                  <div className="text-2xl font-bold text-green-700">{formatSize(compressedFile.size)}</div>
                </div>
              </div>
              
              <div className="inline-block bg-white px-4 py-2 rounded-lg border border-green-200 text-green-700 font-semibold mb-6 shadow-sm">
                Saved {((1 - compressedFile.size / file.size) * 100).toFixed(1)}%
              </div>

              <div>
                <button 
                  onClick={handleDownload}
                  className="inline-flex items-center px-8 py-3.5 bg-green-600 text-white rounded-xl font-bold text-lg hover:bg-green-700 transition-colors shadow-sm"
                >
                  <Download className="w-5 h-5 mr-2" /> Download Compressed Image
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </ToolPage>
  );
}
