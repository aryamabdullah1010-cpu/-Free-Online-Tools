import { useState, useRef } from 'react';
import { PDFDocument } from 'pdf-lib';
import { FileDown, ShieldCheck, X, Download } from 'lucide-react';
import ToolPage from '../../components/tools/ToolPage';

export default function PdfCompressor() {
  const [file, setFile] = useState<File | null>(null);
  const [compressedBlob, setCompressedBlob] = useState<Blob | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type === 'application/pdf') {
      setFile(droppedFile);
      setCompressedBlob(null);
    }
  };

  const compressPdf = async () => {
    if (!file) return;
    setIsProcessing(true);
    setCompressedBlob(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      
      // Load the PDF
      const pdfDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
      
      // Save it with basic optimizations. 
      // Note: In-browser PDF compression is limited. It removes unused objects and uses object streams.
      // It will not downsample images like dedicated server-side tools (Ghostscript, etc).
      const pdfBytes = await pdfDoc.save({ useObjectStreams: true });
      
      const newBlob = new Blob([pdfBytes as unknown as BlobPart], { type: 'application/pdf' });
      setCompressedBlob(newBlob);
      
    } catch (error) {
      console.error(error);
      alert('Failed to process PDF. It might be encrypted or corrupted.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!compressedBlob || !file) return;
    const url = URL.createObjectURL(compressedBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `compressed-${file.name}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const clear = () => {
    setFile(null);
    setCompressedBlob(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getSavedPercentage = () => {
    if (!file || !compressedBlob) return 0;
    const saved = ((file.size - compressedBlob.size) / file.size) * 100;
    return saved > 0 ? saved : 0;
  };

  return (
    <ToolPage
      title="PDF Compressor"
      description="Reduce PDF file size by optimizing document structure."
      howToSteps={[
        { title: 'Upload PDF', description: 'Select the PDF file you want to compress.' },
        { title: 'Compress Locally', description: 'The file is optimized instantly in your browser.' },
        { title: 'Download', description: 'Save the optimized PDF to your device.' }
      ]}
      faqs={[
        {
          question: 'Why didn\'t my PDF get much smaller?',
          answer: 'Client-side (browser) PDF compression is currently limited to structural optimization (removing unused objects, using object streams). It cannot drastically reduce the resolution of embedded images like heavy desktop software can. If your PDF is mostly text, it may already be highly optimized.'
        },
        {
          question: 'Are my files kept private?',
          answer: 'Yes! The optimization happens entirely on your device using JavaScript. We never upload your sensitive documents to any server.'
        }
      ]}
    >
      <div className="flex items-center justify-center p-4 bg-green-50 text-green-800 rounded-xl border border-green-200 mb-8">
        <ShieldCheck className="w-5 h-5 mr-2 flex-shrink-0" />
        <span className="text-sm font-medium">Your PDF is processed locally in your browser. No files are uploaded to our servers.</span>
      </div>

      {!file ? (
        <div 
          className="border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:bg-slate-50 transition-colors cursor-pointer mb-8"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleFileDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <FileDown className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">Upload PDF Document</h3>
          <p className="text-slate-500 mb-6">Select a PDF to compress</p>
          <button className="bg-slate-900 text-white px-6 py-2.5 rounded-xl font-medium hover:bg-slate-800 transition-colors pointer-events-none">
            Select PDF
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="application/pdf"
            onChange={(e) => {
              if (e.target.files?.[0]) {
                setFile(e.target.files[0]);
                setCompressedBlob(null);
              }
            }}
          />
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center space-x-4 overflow-hidden">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <FileDown className="w-6 h-6" />
              </div>
              <div className="truncate pr-4">
                <div className="font-semibold text-slate-900 truncate">{file.name}</div>
                <div className="text-sm text-slate-500">{formatSize(file.size)}</div>
              </div>
            </div>
            <button 
              onClick={clear}
              disabled={isProcessing}
              className="p-2 text-slate-400 hover:text-red-500 bg-white rounded-full border border-slate-200 shadow-sm flex-shrink-0 disabled:opacity-50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {!compressedBlob ? (
            <button 
              onClick={compressPdf}
              disabled={isProcessing}
              className="w-full flex items-center justify-center bg-blue-600 text-white px-6 py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50"
            >
              {isProcessing ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Optimizing Structure...
                </span>
              ) : (
                <>Compress PDF</>
              )}
            </button>
          ) : (
            <div className="bg-white border border-slate-200 rounded-2xl p-6 text-center animate-in fade-in zoom-in duration-300 shadow-sm">
              <h3 className="text-xl font-bold text-slate-900 mb-4">Optimization Complete</h3>
              
              <div className="flex justify-center items-center gap-8 mb-6">
                <div>
                  <div className="text-sm text-slate-500 uppercase tracking-wide font-semibold mb-1">Original Size</div>
                  <div className="text-2xl font-bold text-slate-700">{formatSize(file.size)}</div>
                </div>
                <div className="text-slate-300 text-3xl">→</div>
                <div>
                  <div className="text-sm text-blue-600 uppercase tracking-wide font-semibold mb-1">New Size</div>
                  <div className="text-2xl font-bold text-blue-700">{formatSize(compressedBlob.size)}</div>
                </div>
              </div>
              
              {getSavedPercentage() > 0 ? (
                <div className="inline-block bg-green-50 px-4 py-2 rounded-lg border border-green-200 text-green-700 font-semibold mb-6 shadow-sm">
                  Saved {getSavedPercentage().toFixed(1)}%
                </div>
              ) : (
                <div className="inline-block bg-slate-50 px-4 py-2 rounded-lg border border-slate-200 text-slate-600 font-medium mb-6 shadow-sm max-w-sm">
                  This PDF was already highly optimized. Client-side compression couldn't reduce it further without losing data.
                </div>
              )}

              <div>
                <button 
                  onClick={handleDownload}
                  className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3.5 bg-blue-600 text-white rounded-xl font-bold text-lg hover:bg-blue-700 transition-colors shadow-sm"
                >
                  <Download className="w-5 h-5 mr-2" /> Download Document
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </ToolPage>
  );
}
