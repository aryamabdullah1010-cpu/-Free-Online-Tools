import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import SEO from '../../components/seo/SEO';
import { blogPosts } from '../../data/blogData';
import AdSlot from '../../components/ads/AdSlot';

export default function Blog() {
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <SEO 
        title="Blog - QuickTools" 
        description="Tips, guides, and tutorials on how to manage your digital files, images, PDFs, and more." 
      />
      
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">QuickTools Blog</h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Tips, guides, and tutorials on how to manage your digital files, images, PDFs, and more.
          </p>
        </div>

        <AdSlot className="mb-12" />

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {blogPosts.map(post => (
            <article key={post.slug} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col hover:shadow-md transition-shadow">
              <div className="p-6 flex flex-col flex-grow">
                <div className="text-sm text-slate-500 mb-3">{post.date}</div>
                <h2 className="text-xl font-bold text-slate-900 mb-3 line-clamp-2">
                  <Link to={`/blog/${post.slug}`} className="hover:text-blue-600 transition-colors">
                    {post.title}
                  </Link>
                </h2>
                <p className="text-slate-600 mb-6 flex-grow line-clamp-3">
                  {post.excerpt}
                </p>
                <Link 
                  to={`/blog/${post.slug}`}
                  className="inline-flex items-center text-blue-600 font-semibold hover:text-blue-700 mt-auto group"
                >
                  Read Article
                  <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
