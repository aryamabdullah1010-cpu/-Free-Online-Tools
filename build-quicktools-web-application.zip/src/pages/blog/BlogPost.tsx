import { useParams, Navigate, Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import SEO from '../../components/seo/SEO';
import { getBlogPost } from '../../data/blogData';
import { toolsData } from '../../data/toolsData';
import ToolCard from '../../components/tools/ToolCard';
import AdSlot from '../../components/ads/AdSlot';

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = slug ? getBlogPost(slug) : null;

  if (!post) {
    return <Navigate to="/404" replace />;
  }

  const relatedToolsCards = toolsData.filter(tool => post.relatedTools.includes(tool.id));

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <SEO title={`${post.title} - QuickTools Blog`} description={post.excerpt} />
      
      <div className="max-w-3xl mx-auto">
        {/* Breadcrumbs */}
        <nav className="flex text-sm text-slate-500 mb-8" aria-label="Breadcrumb">
          <ol className="flex items-center space-x-2">
            <li><Link to="/" className="hover:text-blue-600 transition-colors">Home</Link></li>
            <li><ChevronRight className="w-4 h-4" /></li>
            <li><Link to="/blog" className="hover:text-blue-600 transition-colors">Blog</Link></li>
            <li><ChevronRight className="w-4 h-4" /></li>
            <li className="text-slate-900 font-medium truncate max-w-[200px]" aria-current="page">{post.title}</li>
          </ol>
        </nav>

        <article className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 md:p-10 mb-12">
          <header className="mb-10 text-center">
            <div className="text-slate-500 mb-4">{post.date} • By {post.author}</div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">{post.title}</h1>
            <p className="text-xl text-slate-600 leading-relaxed">{post.excerpt}</p>
          </header>

          <AdSlot className="mb-10" />

          <div className="prose prose-slate lg:prose-lg max-w-none">
            {/* We could render actual markdown here, but since we are doing static content for now: */}
            <p>
              Welcome to this comprehensive guide on <strong>{post.title}</strong>. 
              In today's digital world, managing file sizes and formats is more important than ever. 
              Whether you are a developer, designer, or just someone trying to email a document, knowing the right tools and techniques can save you significant time.
            </p>
            <h2>Why Does This Matter?</h2>
            <p>
              Large files take longer to upload, download, and store. 
              They consume precious bandwidth and storage space. 
              By optimizing your files, you improve website load times (crucial for SEO), reduce storage costs, and make sharing easier.
            </p>
            <h2>The Best Approach</h2>
            <p>
              The most efficient way to handle these tasks is by using client-side tools. 
              This means the processing happens directly in your web browser. 
              Your files are never uploaded to a remote server, ensuring maximum privacy and blazing fast speeds.
            </p>
            <h3>Step-by-Step Instructions</h3>
            <ol>
              <li>Choose the appropriate tool for your specific need from our collection.</li>
              <li>Upload or drag-and-drop your file directly into the browser window.</li>
              <li>Select your desired settings (quality, dimensions, format, etc.).</li>
              <li>Click process and download your optimized file instantly.</li>
            </ol>
            <p>
              We built QuickTools specifically to solve these problems without the hassle of subscriptions or intrusive tracking.
            </p>
          </div>
        </article>

        {relatedToolsCards.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Tools Mentioned in this Article</h2>
            <div className="grid sm:grid-cols-2 gap-6">
              {relatedToolsCards.map(tool => (
                <ToolCard key={tool.id} tool={tool} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
