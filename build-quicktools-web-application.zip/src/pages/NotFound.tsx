import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import SEO from '../components/seo/SEO';

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center bg-slate-50 px-4 sm:px-6 lg:px-8">
      <SEO title="Page Not Found - QuickTools" description="The page you are looking for does not exist." />
      <div className="max-w-md w-full text-center">
        <h1 className="text-9xl font-black text-slate-200">404</h1>
        <h2 className="text-3xl font-bold text-slate-900 mt-4 mb-2">Page Not Found</h2>
        <p className="text-slate-600 mb-8">
          The tool or page you're looking for doesn't exist or has been moved.
        </p>
        <Link 
          to="/"
          className="inline-flex items-center justify-center bg-blue-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors shadow-sm"
        >
          <Home className="w-5 h-5 mr-2" />
          Back to Home
        </Link>
      </div>
    </div>
  );
}
