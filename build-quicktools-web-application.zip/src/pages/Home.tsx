import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, ArrowRight, Zap, Shield, Smartphone } from 'lucide-react';
import SEO from '../components/seo/SEO';
import AdSlot from '../components/ads/AdSlot';
import ToolCard from '../components/tools/ToolCard';
import { toolsData } from '../data/toolsData';

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/tools?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const popularTools = toolsData.filter(tool => tool.popular).slice(0, 6);

  return (
    <div>
      <SEO 
        title="QuickTools - Free Online Tools for Everyday Tasks"
        description="Compress, convert, resize, calculate and create — quickly and completely free. Simple tools for files, images, PDFs, text and everyday calculations."
      />

      {/* Hero Section */}
      <section className="bg-slate-50 border-b border-slate-200 py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight mb-6">
            Free Online Tools <br className="hidden sm:block" />
            <span className="text-blue-600">That Just Work</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-600 mb-10 max-w-2xl mx-auto">
            Compress, convert, resize, calculate and create — quickly and completely free. No sign-up required.
          </p>

          <form onSubmit={handleSearch} className="max-w-2xl mx-auto relative mb-10">
            <div className="relative flex items-center">
              <Search className="absolute left-4 w-6 h-6 text-slate-400" />
              <input
                type="text"
                placeholder="Search for a tool... (e.g. Image Compressor)"
                className="w-full pl-14 pr-4 py-4 rounded-2xl border-2 border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 text-lg transition-all outline-none shadow-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button 
                type="submit"
                className="absolute right-3 bg-blue-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-blue-700 transition-colors"
              >
                Search
              </button>
            </div>
          </form>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/tools" className="w-full sm:w-auto bg-slate-900 text-white px-8 py-3.5 rounded-xl font-semibold text-lg hover:bg-slate-800 transition-colors flex items-center justify-center shadow-md hover:shadow-lg">
              Explore Tools
              <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
            <a href="#popular-tools" className="w-full sm:w-auto bg-white text-slate-700 border-2 border-slate-200 px-8 py-3.5 rounded-xl font-semibold text-lg hover:border-slate-300 hover:bg-slate-50 transition-colors flex items-center justify-center">
              Popular Tools
            </a>
          </div>
        </div>
      </section>

      {/* Top Ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <AdSlot />
      </div>

      {/* Popular Tools Section */}
      <section id="popular-tools" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Popular Tools</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Our most frequently used free tools. Everything happens right in your browser whenever possible.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularTools.map(tool => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>

        <div className="text-center mt-12">
          <Link to="/tools" className="inline-flex items-center text-blue-600 font-semibold hover:text-blue-700 text-lg">
            View All Tools
            <ArrowRight className="w-5 h-5 ml-2" />
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-slate-900 text-white py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Why QuickTools?</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              We built these tools because we were tired of slow websites, fake download buttons, and intrusive ads.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600/20 text-blue-400 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Extremely Fast</h3>
              <p className="text-slate-400">
                Tools run in your browser whenever possible using modern web technologies, providing instant results without waiting for uploads.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600/20 text-blue-400 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Privacy First</h3>
              <p className="text-slate-400">
                Your files stay on your device for most tools. We don't store your data, images, or documents on our servers.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600/20 text-blue-400 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Smartphone className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Mobile Friendly</h3>
              <p className="text-slate-400">
                Whether you're on a laptop, tablet, or smartphone, every interface is optimized for your screen size and touch.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold text-slate-900 mb-2">Are these tools really free?</h3>
            <p className="text-slate-600">Yes, completely free. We keep the site running through non-intrusive advertisements. There are no hidden fees or premium tiers.</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold text-slate-900 mb-2">Do you save my files?</h3>
            <p className="text-slate-600">No. Most of our tools (like the image compressor and resizer) process files entirely within your web browser. Your files never leave your device.</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold text-slate-900 mb-2">Can I use this on my phone?</h3>
            <p className="text-slate-600">Absolutely. Every tool is designed to be fully responsive and works perfectly on iOS and Android devices.</p>
          </div>
        </div>
      </section>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <AdSlot />
      </div>
    </div>
  );
}
